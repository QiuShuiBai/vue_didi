<template>
  <div class="page__bd center">二手车</div>
</template>

<script>
export default {
  name: "borCar"
}
</script>

<style lang="stylus" scoped>
</style>
