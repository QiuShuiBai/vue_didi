<template>
  <div id="app">
    <!-- <router-view></router-view> -->
    <cube-scroll :listenScroll="listenScroll"
      :data="items" :options="options" @click="zczc"
      :direction="direction" ref="scroll">
    <ul class="hd__mid-content">
      <li class="hd__mid-title" @click="zc" v-for="(item, index) in items"
        :key="index">
        {{item.title}}
      </li>
    </ul>
    </cube-scroll>
  </div>
</template>

<script>
export default {
  data() {
    return {
      listenScroll: true,
      items: [{
        title: "快车",
        path: "/fastCar"
      },
      {
        title: "出租车",
        path: "/taxiCar"
      },
      {
        title: "顺风车",
        path: "/freeCar"
      },
      {
        title: "代驾",
        path: "/desDri"
      },
      {
        title: "自驾租车",
        path: "/borCar"
      }],
      direction: "horizontal",
      options: {
        probeType: 2,
        startX: 0,
        tap: true,
        scrollbar: {
          fade: true
        }
      },
      scrollX: true
    }
  },
  mounted() {
    this.$refs.scroll.$refs.listWrapper.childNodes[0].addEventListener("tap", (e) => {
      // that.e.srcElement
      this.$refs.scroll.scrollToElement(e.srcElement, 1000, true, true, "bounce")
    })
    this.$nextTick(() => {
      this.$refs.scroll.scroll.on("scrollEnd", function(qq) {
      })
    })
  },
  methods: {
    zc(event) {
    }
  }
}

</script>

<style lang="stylus" >
.cube-scroll-wrapper
  width 7.813333rem /* 586/75 */
  height 36px
.cube-scroll-content
  width 9rem
  height 36px
.hd__mid-content
  display flex
  width 9rem
  height 36px
  justify-content space-around
.hd__mid-title
  text-align center
  font-size 14px
  color #666666
  line-height 36px
</style>
